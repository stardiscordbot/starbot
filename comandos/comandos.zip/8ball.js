const Discord = require("discord.js");
const config = require('../config.json')
const pr = require('../mongodb/prefix.js')

var eightball = [ 
        "sim",
        "não",
        "talvez",
        "provavelmente",
        "acho que não",
        "nunca",
        "você pode tentar...",
        "você Decide!",
        "sem Sombra de duvidas!",
        "não pergunte isto agora",
        "pergunte a meu patrão",
        "não é da sua conta",
        "tu que deixa",
]

module.exports.run = async (client,message,args) => {
    pr.findOne({name: "prefix", preid: message.guild.id}).then(res => {
        let prefix = res ? res.prefix : config.prefix;
     if (args[0] != null) {
        var embed = new Discord.MessageEmbed()
        .setAuthor(`${client.user.username} | Oráculo`, client.user.displayAvatarURL())
        .setColor(config.color)
        .setThumbnail("https://upload.wikimedia.org/wikipedia/commons/thumb/f/fd/8-Ball_Pool.svg/1024px-8-Ball_Pool.svg.png")
        .setDescription(`<:pensando:772519888379445248> | **Meu oráculo diz:**\n\n\`${message.author.username}, de acordo com muitos estudos cientificos minha resposta é ${eightball[Math.floor(Math.random() * eightball.length).toString(16)]}\``)
        .setFooter(`Comando Executado por ${message.author.tag} • Versão: ${config.versão}`, message.author.displayAvatarURL({ dynamic: true, size: 2048 }))
        message.channel.send(embed)
    }
    
     else message.reply(`qual sua Pergunta? ultilize ${prefix}8ball pergunta`)
    })
}
module.exports.help = {
    name: "8ball",
    aliases: ['8b'],
    status: 'on'
}
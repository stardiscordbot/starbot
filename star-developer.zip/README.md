<h1 align="center">✨ Hi my name is Star! ✨</h1>
<p align="center">
<a href="https://top.gg/bot/719524114536333342">
    <img src="https://top.gg/api/widget/719524114536333342.svg" alt="Star™" />
</a>
</p>

<p align="center">
<a href='https://infinitybotlist.com/bots/719524114536333342' title='widget'> <img src='https://infinitybotlist.com/bots/719524114536333342/widget?size=large'></img></a>
</p>

## 📋 A multifunctional bot for discord
- Autorole
- MessageLogs
- Welcome
- Goodbye
- StarBoard
- ReactionRoles
- Giveaways
- SlashCommands
- Clusters
- Shards
## 👨‍💻 Less work and more fun!
Star is a multifunctional bot, where you get all kinds of things. Music, Moderation, Multi-Language, Economy, Giveaways, Fun, Chat Events, ReactionRoles, Support, Website and More! What we want most is peace of mind for your server.
## ✨ Stars... is to eat?
No, but I was made to help on your server, developed in the discord.js library using [JavaScript](https://developer.mozilla.org/en-US/docs/Web/JavaScript) & [NodeJS](https://nodejs.org/en/)
## 💁 What if I need help?
You can enter my support server here: [Click Here](https://discord.gg/2pFH6Yy)
## 🥳 Convinced me, how do I add?
If you want to use star on your server, you can [Click Here](https://discord.com/oauth2/authorize?client_id=719524114536333342&scope=bot&permissions=805432446) and join more than 600 servers in the StarDreams family
## 💻 Hosting
Thanks [www.openode.io](https://www.openode.io) for the hosting!
## 🐦 Github Status:
[![Node Version](https://img.shields.io/badge/Node.JS-43853D.svg?style=for-the-badge&logo=node.js&logoColor=white)](https://nodejs.org/en/download/) [![Issues](https://img.shields.io/github/issues/yADGithub/starbot?style=for-the-badge&color=green)](https://github.com/yADGithub/starbot/issues) [![](https://img.shields.io/github/issues-pr/yADGithub/starbot?style=for-the-badge&color=green)](https://github.com/yADGithub/starbot/pulls)

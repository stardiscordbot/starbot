const Sharder = require('eris-sharder').Master;
const sharder = new Sharder(token, pathToMainFile, options);
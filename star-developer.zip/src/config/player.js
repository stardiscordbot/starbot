module.exports = {
    "spotify": {
        "id": "1d72c2aa31ec403d9406bbadbde48318",
        "secret": "c97dd977256e43ba9a7caf79fb153b77"
    },
}
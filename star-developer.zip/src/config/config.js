module.exports = {
  prefix: ['s!', 's.', 'star!', 'star.', 'star'],
  token: 'ODM5NjM4Mjk4NzIwNDY5MDMy.YJMkGg.3TCTs_g1NK4LYnB7EBXzHnj10kA',
  database: {
      mongo: 'mongodb+srv://stardb:gbsIv^oCdsOZ@cluster0-avxy3.mongodb.net/stardeveloper?retryWrites=true&w=majority'
  },
  bitly: '05cb6b66776ad6e509e502e69ee40f9f2e9f6fa6'
}
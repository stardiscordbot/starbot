module.exports = {
  prefix: ['LISTA DE PREFIXOS'],
  token: 'TOKEN DO BOT AQUI',
  database: {
      mongo: 'URL DA MONGO AQUI'
  },
  bitly: 'KEY DA API DO BIT.LY (FIXADO NO GERAL DO SERVIDOR DE TESTES)'
}
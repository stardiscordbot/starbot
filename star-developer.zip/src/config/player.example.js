module.exports = {
    "spotify": {
        "id": "https://developer.spotify.com",
        "secret": "https://developer.spotify.com"
    },
}
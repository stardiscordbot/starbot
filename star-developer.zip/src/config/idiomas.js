module.exports = {
  pt_br: require('../idiomas/pt-br.json'),
  en_us: require('../idiomas/en-us.json'),
  pt_zeDroguinha: require('../idiomas/pt-zeDroguinha.json')
}
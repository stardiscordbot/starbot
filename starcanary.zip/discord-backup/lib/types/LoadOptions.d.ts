export interface LoadOptions {
	clearGuildBeforeRestore: boolean;
	maxMessagesPerChannel?: number;
}

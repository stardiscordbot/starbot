export interface ChannelPermissionsData {
	roleName: string;
	allow: number;
	deny: number;
}

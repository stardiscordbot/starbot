export interface RoleData {
	name: string;
	color: string;
	hoist: boolean;
	permissions: number;
	mentionable: boolean;
	position: number;
}

module.exports = {
	Player: require('./src/Player'),
};

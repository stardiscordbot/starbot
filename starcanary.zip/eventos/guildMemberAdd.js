const {client} = require("../bot.js");
const config = require("../config.json");
const Discord = require('discord.js')
const c = require('colors')
// Arquivos
const bldb = require("../mongodb/blacklist.js");
const dc = require('../mongodb/dc.js')
const pr = require("../mongodb/prefix");
const autorole = require('../mongodb/autorole.js');
const welcomeChannel = require('../mongodb/WelcomeChannel.js');
const votosZuraaa = require('../votosZuraaa.js');
const logChannel = require('../mongodb/messagelog.js');
const Money = require("../mongodb/money.js");
const antilink = require('../mongodb/antilink');
// Inicio do Code
client.on('guildMemberAdd', async member => {
// Carinha
let guild = await client.guilds.cache.get("714930300924461057");
let channel = await client.channels.cache.get("755277456969302057");
let emoji = await member.guild.emojis.cache.find(emoji => emoji.name === "nomedoemoji");
if (guild != member.guild) {
  return
 } else {
  channel.send(`<a:welcome:755429019230404618>  Olá ${member.user} Bem-Vindo(a) a **${guild.name}** Passa em <#755277453408337981> para obter tags <a:hypegato:755445409157218484>`).then(msg=> {
  msg.delete({ timeout: 30000 });
  })
}
// Welcome
    welcomeChannel.findOne({ GuildID: member.guild.id }, async (err, data) => {
      if(!data) return;
let welcomechanneldata = client.channels.cache.get(data.WelcomeChannelID)
if(!welcomechanneldata) return;
  let join = new Discord.MessageEmbed()
  .setTitle(`${member.guild.name}`)
  .setDescription(`Olá ${member.user} seja bem-vindo ao servidor\n Atualmente estamos com **${member.guild.memberCount} membros**, divirta-se conosco! :heart:`)
  .setColor('#ff00c2')
 welcomechanneldata.send(join)
    })
    // Autorole
    autorole.findOne({ GuildID: member.guild.id }, async (err, data432) => {
        if(!data432) return;
        let autorolerole = member.guild.roles.cache.get(data432.RoleID)
        member.roles.add(autorolerole)
      })
    // Fim
})
# Starbot

Olá meu nome é Star sou focada em Comandos Variados! Me Adicione! E Veja do que sou capaz!


### Créditos
[discord.js](https://www.npmjs.com/package/discord.js)

## Como usar?

Preencha o arquivo `config.example.json` com as informações necessárias, salve e renomeie para `config.json`

* Abra o terminal e de o seguinte comando:
```npm i```

## Inicialização

* Abra o terminal/command line no diretório onde você baixou o código e execute `npm start`

O bot deve estar online e funcionando!